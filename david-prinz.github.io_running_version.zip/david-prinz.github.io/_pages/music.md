---
layout: archive
permalink: /music/
title: "Music"
author_profile: true
---

# ---

Music is also a very important part of my life. I have started playing the piano very early and do enjoy playing at jazz sessions or open stages. I am very interested in starting a new band project around modern jazz, so feel free to contact me via [e-mail](mailto:prinz@math.hu-berlin.de) if you wish.

More content will be added soon.
